// ! dom ---> document object model

// let x=document.getElementById("header")
// console.log(x)
// x.innerHTML="vijay"


// let x=document.getElementsByClassName("header");
// console.log(x)
// x[0].innerHTML="gowsik"
// x[0].style.color="red"
// x[0].style.backgroundColor="yellow"


// let x=document.getElementsByTagName("h1")
// console.log(x)
// x[0].style.background="red"
// x[0].style.color="white"

// x[1].style.fontSize="100px"
// x[1].style.fontFamily="arial"


// let x=document.getElementsByName("vj");
// console.log(x)

// x[0].style.width="100%"
// x[0].style.height="5vh"
// x[0].style.marginTop="20px"



// let x=document.querySelector("#head");
// console.log(x)

// let y=document.querySelector(".navbar");
// console.log(y)

// let z=document.querySelector("h1");
// console.log(z)

// let x=document.querySelectorAll('h1')
// console.log(x)

// let div=document.createElement('div')
// div.setAttribute("id","container")

// console.log(div.getAttribute("id"))

// let h2=document.createElement("h2")
// h2.setAttribute("class","header")
// console.log(h2.getAttribute("class"))
// h2.innerText="i am a header"
// console.log(h2.hasAttribute("class"))
// let para=document.createElement('p');
// para.setAttribute("class","para")


// para.innerText="Lorem ipsum dolor sit, amet consectetur adipisicing elit. Quam architecto tenetur esse, s"
// console.log(para.getAttribute("class"))
// // para.removeAttribute(".para")


// para.removeAttribute("class")

// console.log(para.hasAttribute("class"))
// // para.innerText="hello i am para"

// // para.innerHTML="hello i ma para"

// div.appendChild(h2)
// div.appendChild(para)
// document.body.append(div)


// !classlist

let x=document.getElementsByTagName("div")

x.add="v"























